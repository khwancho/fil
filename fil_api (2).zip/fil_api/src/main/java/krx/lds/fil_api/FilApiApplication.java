package krx.lds.fil_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilApiApplication.class, args);
	}

}
